package com.spring.entity;

public class AdminInfo {

}

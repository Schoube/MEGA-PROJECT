package com.spring.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PlasticRepo extends JpaRepository<Plasticproducts, Integer> {

}

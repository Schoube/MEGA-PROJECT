package com.edac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MegaprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
